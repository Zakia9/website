import React from "react";

const Footer = () => {
  return (
    <div className="bg-slate-200 text-md p-4 text-center text-black">
      Z.S.A Copyright Reserverd ® 
    </div>
  );
};

export default Footer;
